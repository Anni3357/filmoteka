﻿
namespace Filmoteka
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.yearBox = new System.Windows.Forms.TextBox();
            this.urlBox = new System.Windows.Forms.TextBox();
            this.directorBox = new System.Windows.Forms.TextBox();
            this.ganreBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(34, 50);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(722, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(164, 245);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(319, 22);
            this.nameBox.TabIndex = 1;
            // 
            // yearBox
            // 
            this.yearBox.Location = new System.Drawing.Point(164, 273);
            this.yearBox.Name = "yearBox";
            this.yearBox.Size = new System.Drawing.Size(319, 22);
            this.yearBox.TabIndex = 2;
            // 
            // urlBox
            // 
            this.urlBox.Location = new System.Drawing.Point(164, 301);
            this.urlBox.Name = "urlBox";
            this.urlBox.Size = new System.Drawing.Size(319, 22);
            this.urlBox.TabIndex = 3;
            // 
            // directorBox
            // 
            this.directorBox.Location = new System.Drawing.Point(164, 329);
            this.directorBox.Name = "directorBox";
            this.directorBox.Size = new System.Drawing.Size(319, 22);
            this.directorBox.TabIndex = 4;
            // 
            // ganreBox
            // 
            this.ganreBox.Location = new System.Drawing.Point(164, 357);
            this.ganreBox.Name = "ganreBox";
            this.ganreBox.Size = new System.Drawing.Size(319, 22);
            this.ganreBox.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(549, 259);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 36);
            this.button1.TabIndex = 6;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ganreBox);
            this.Controls.Add(this.directorBox);
            this.Controls.Add(this.urlBox);
            this.Controls.Add(this.yearBox);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.TextBox yearBox;
        private System.Windows.Forms.TextBox urlBox;
        private System.Windows.Forms.TextBox directorBox;
        private System.Windows.Forms.TextBox ganreBox;
        private System.Windows.Forms.Button button1;
    }
}