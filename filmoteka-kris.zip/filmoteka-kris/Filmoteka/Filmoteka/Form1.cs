﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Filmoteka
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=LAPTOP-6038JFDU;Initial Catalog=FilmDB;Integrated Security=True";
            SqlConnection connection = new SqlConnection(connectionString);
            try
            {
                // Открываем подключение
                connection.Open();
                Console.WriteLine("Подключение открыто");
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                // закрываем подключение
                connection.Close();
                Console.WriteLine("Подключение закрыто...");
            }

            Console.Read();
            string stringCommand = "select [id_film], [name], [year], [director], [ganre] from [Films]";
            SqlDataAdapter da = new SqlDataAdapter(stringCommand, connection);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=LAPTOP-6038JFDU;Initial Catalog=FilmDB;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionString); // создаем подключение

            ///*SqlCommand cmd = new SqlCommand("insert into Films values ('" + nameBox.Text + "','" + yearBox.Text + "','" + urlBox.Text + "','" + directorBox.Text + "','" + ganreBox.Text + "')", conn);*/ // создаем SQL запрос
            //SqlCommand cmd = new SqlCommand(" INSERT INTO Films (name, year, url, director, ganre) values (nameBox.Text, yearBox.Text,urlBox.Text,directorBox.Text,ganreBox.Text)", conn);
            //conn.Open();
            //cmd.ExecuteNonQuery(); // выполняем запрос на сервер
            //conn.Close(); // закрываем соединение
            //MessageBox.Show("Вы успешно зарегистрировались!");

        }
    }
}
